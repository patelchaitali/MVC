
Installation steps:


Step 1:

	copy MVC directory in root location. 
	
	linux
	(e.g.: /var/www/MVC )

	windows 
	(e.g.: /wamp/www/MVC)

Step 2: 

Create database (e.g: TestProject)

step 3:

import sql file (products.sql) in created database

step 4:

change database credentials in app/core/config.php

step 5:

Open project in Browser (e.g.: http://localhost/mvc)

