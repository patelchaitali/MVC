<?php 
$config=array(
	
	
	//change database credentials
	
	
'host'=>'localhost', //databse connection host
	
'username'=>'root',  //username for database
	
'password'=>'root',  
	
'dbname'=>'test1'    //database name

	
	
	
	
	
	
	

);
?>