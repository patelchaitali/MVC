<?php
include('header.php');
include('nav.php');
?>
    
<div class="container-fluid">
	<h3>All Products</h3>
<div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Image</th>
					<th>Name</th>
                  <th>PartNumber</th>
                  <th>Description</th>
                  <th>Quantity</th>
					<th>Cost Price</th>
					  <th>Sale Price</th>
					<th>VAT rate</th>
					<th> </th>
                </tr>
              </thead>
              <tbody>
			<?php foreach($data as $row) { ?>
                <tr>
				  <td><?php if(isset($row->id)){ echo $row->id; }?></td>
					 <td><img src="<?php if(isset($row->image)){ echo 'public/upload/'.$row->image; }?>" alt="<?php if(isset($row->name)){ echo $row->name; }?>" class="img-thumbnail  mx-auto d-block" width="100" height="100"></td>	
					
                  <td><?php if(isset($row->name)){ echo $row->name; }?></td>
					<td><?php if(isset($row->part_number)){ echo $row->part_number; }?></td>
					<td><?php if(isset($row->description)){  echo $row->description; }?></td>
					<td><?php if(isset($row->stock_quantity)){ echo $row->stock_quantity; }?></td>
					<td><?php if(isset($row->cost_price)){ echo $row->cost_price; }?></td>
					<td><?php if(isset($row->selling_price)){  echo $row->selling_price; }?></td>
					<td><?php if(isset($row->vat_rate)){  echo $row->vat_rate; }?></td>
					<td><a href="edit/<?php echo $row->id; ?>" class="btn btn-info" role="button">Edit</a><a href="delete/<?php echo $row->id; ?>" class="btn btn-danger" role="button" data-toggle="confirmation" data-title="Are you sure?"
    >Delete</a></td>
                </tr>
 
				  <?php } ?>
             
              </tbody>
            </table>
          </div>
</div>
  </body>
</html>
