<?php

require_once('core/App.php');