<?php

require_once('app/models/model.php');

class Home
{
	private $model;
	public function __construct()
	{
	$this->model= new db;
	}
	public function index()
	{
		$data=$this->model->list_all('products',null); 
		$num_products=$this->model->count_rows();
		//print_r($data);
		include_once('app/views/home.php');
	}
 
	public function delete($id)
	{
		
	 
		$del=$this->model->delete($id);
		header('Location: '.$_SERVER['PHP_SELF']); 
		
	}
	public function edit($id)
	{
		
		$data=$this->model->list_all('products','id ='.$id); 
	
	 
		foreach($data as $row) {
		$name= isset($row->name) ? $row->name :''; 
		$part_number=	 isset($row->part_number) ? $row->part_number:'';
			$description= isset($row->description) ?  $row->description : '';
			$stock_quantity= isset($row->stock_quantity) ? $row->stock_quantity: '';
			$cost_price= isset($row->cost_price) ? $row->cost_price :'';
			$selling_price= isset($row->selling_price) ? $row->selling_price:'';
			$vat_rate= isset($row->vat_rate)  ? $row->vat_rate :'';
			
		}
		$form='Edit '.$name ;
		
			include_once('app/views/edit.php');
	}
	
	
	public function create()
	{   $form='Create';
		include_once('app/views/edit.php');
	}
	
	
	public function update()
	{
		 
if($_SERVER['REQUEST_METHOD'] == 'POST'){

 if(move_uploaded_file($_FILES["image"]["tmp_name"],"public/upload/" . $_POST['part_number'].$_FILES["image"]["name"])){
$data = array(
'name' =>$_POST['name'],
'part_number' =>$_POST['part_number'],
'description' => $_POST['description'],
	'image' => $_POST['part_number'].$_FILES["image"]["name"],
	'stock_quantity' => $_POST['stock_quantity'],
	'cost_price' => $_POST['cost_price'],
	'selling_price' => $_POST['selling_price'],
	'vat_rate' => $_POST['vat_rate']
);
	 if($_POST['id']){$this->model->update($data,$_POST['id']);}else{
$this->model->insert($data);}
}
}
return $this->index();
	}
	
}